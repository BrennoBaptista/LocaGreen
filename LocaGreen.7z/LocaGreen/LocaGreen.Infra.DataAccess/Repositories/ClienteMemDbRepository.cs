﻿using LocaGreen.Domain.Entities;
using LocaGreen.Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace LocaGreen.Infra.DataAccess.Repositories
{
    /// <summary>
    /// Implementa os métodos de manipulação definidos no repositório do Cliente
    /// Salva os dados na memória
    /// </summary>
    public class ClienteMemDbRepository : IClienteRepository
    {
        private readonly static ICollection<Cliente> _clientes = new List<Cliente>();

        public bool Create(Cliente entity)
        {
            _clientes.Add(entity);
            return true;
        }

        public bool Delete(Guid id)
        {
            var cliente = Read(id);
            return _clientes.Remove(cliente);
        }

        public Cliente Read(Guid id)
        {
            return _clientes.Single(c => c.Id == id);
        }

        public IEnumerable<Cliente> ReadAll()
        {
            return _clientes;
        }

        public bool Update(Cliente entity)
        {
            Delete(entity.Id);
            return Create(entity);
        }
    }
}