﻿using LocaGreen.Domain.Entities;
using LocaGreen.Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace LocaGreen.Infra.DataAccess.Repositories
{
    /// <summary>
    /// Implementa os métodos de manipulação definidos no repositório do Seguro
    /// Salva os dados na memória
    /// </summary>
    public class SeguroMemDbRepository : ISeguroRepository
    {
        private readonly static ICollection<Seguro> _seguros = new List<Seguro>();

        public bool Create(Seguro entity)
        {
            _seguros.Add(entity);
            return true;
        }

        public bool Delete(Guid id)
        {
            var seguro = Read(id);
            return _seguros.Remove(seguro);
        }

        public Seguro Read(Guid id)
        {
            return _seguros.Single(c => c.Id == id);
        }

        public IEnumerable<Seguro> ReadAll()
        {
            return _seguros;
        }

        public bool Update(Seguro entity)
        {
            Delete(entity.Id);
            return Create(entity);
        }
    }
}