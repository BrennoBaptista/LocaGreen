﻿using LocaGreen.Domain.Entities;
using LocaGreen.Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace LocaGreen.Infra.DataAccess.Repositories
{
    /// <summary>
    /// Implementa os métodos de manipulação definidos no repositório da Locação
    /// Salva os dados na memória
    /// </summary>
    public class LocacaoMemDbRepository : ILocacaoRepository
    {
        private readonly static ICollection<Locacao> _locacoes = new List<Locacao>();

        public bool Create(Locacao entity)
        {
            _locacoes.Add(entity);
            return true;
        }

        public bool Delete(Guid id)
        {
            var locacao = Read(id);
            return _locacoes.Remove(locacao);
        }

        public Locacao Read(Guid id)
        {
            return _locacoes.Single(c => c.Id == id);
        }

        public IEnumerable<Locacao> ReadAll()
        {
            return _locacoes;
        }

        public bool Update(Locacao entity)
        {
            Delete(entity.Id);
            return Create(entity);
        }
    }
}