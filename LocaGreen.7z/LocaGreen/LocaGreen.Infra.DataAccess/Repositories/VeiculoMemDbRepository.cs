﻿using LocaGreen.Domain.Entities;
using LocaGreen.Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace LocaGreen.Infra.DataAccess.Repositories
{
    /// <summary>
    /// Implementa os métodos de manipulação definidos no repositório do Veículo
    /// Salva os dados na memória
    /// </summary>
    public class VeiculoMemDbRepository : IVeiculoRepository
    {
        private readonly static ICollection<Veiculo> _veiculos = new List<Veiculo>();

        public bool Create(Veiculo entity)
        {
            _veiculos.Add(entity);
            return true;
        }

        public bool Delete(Guid id)
        {
            var veiculo = Read(id);
            return _veiculos.Remove(veiculo);
        }

        public Veiculo Read(Guid id)
        {
            return _veiculos.Single(c => c.Id == id);
        }

        public IEnumerable<Veiculo> ReadAll()
        {
            return _veiculos;
        }

        public bool Update(Veiculo entity)
        {
            Delete(entity.Id);
            return Create(entity);
        }
    }
}