using LocaGreen.Domain.Entities;
using LocaGreen.Domain.Interfaces.Repositories;
using LocaGreen.Domain.Services;
using LocaGreen.Domain.ValueObjects;
using LocaGreen.Infra.DataAccess.Repositories;
using NUnit.Framework;
using System;

namespace LocaGreen.Test.DomainServiceUnitTest
{
    public class LocacaoServiceUnitTest
    {
        [SetUp]
        public void Setup()
        {
            RealizarLocacaoComSucesso();
            RealizarLocacaoSemSucesso();
        }

        [Test]
        public void RealizarLocacaoComSucesso()
        {
            // Prepara��o
            ILocacaoRepository locacaoRepository = new LocacaoMemDbRepository();
            var locacaoService = new LocacaoService(locacaoRepository);
            var locacao = new Locacao
            {
                Id = Guid.NewGuid(),
                LocacaoAtiva = true,
                DataLocacao = DateTime.Now,
                DataDevolucao = DateTime.Now.AddDays(7),
                Cliente = new Cliente
                {
                    Id = Guid.NewGuid(),
                    Nome = "Brenno Cesar de Almeida Baptista",
                    Nascimento = DateTime.Parse("08/02/1995"),
                    Telefone = "21982880402",
                    Email = "brenno_baptista@hotmail.com",
                    Cnh = CNH.NewCNH("06711019630", DateTime.Parse("02/22/2019"), DateTime.Parse("02/22/2024")),
                    Identidade = Identidade.NewIdentidade("271032765", "Detran"),
                    Cpf = CPF.NewCPF("14424377741")
                },
                Veiculo = new Veiculo
                {
                    Id = Guid.NewGuid(),
                    VeiculoDisponivel = true,
                    Marca = "Honda",
                    Modelo = "Civic",
                    Ano = "2019",
                    Cor = "Preto",
                    Chassi = Chassi.NewChassi("01234567891234567"),
                    Placa = Placa.NewPlaca("RIO2A19")
                }
            };

            //Execu��o
            var result = locacaoService.RealizarLocacao(locacao);

            //Valida��o           
            Assert.IsTrue(result);
        }
        
        [Test]
        public void RealizarLocacaoSemSucesso()
        {
            // Prepara��o
            ILocacaoRepository locacaoRepository = new LocacaoMemDbRepository();
            var locacaoService = new LocacaoService(locacaoRepository);
            var locacao = new Locacao
            {
                Id = Guid.NewGuid(),
                LocacaoAtiva = true,
                DataLocacao = DateTime.Now.AddDays(7),
                DataDevolucao = DateTime.Now,
                Cliente = new Cliente
                {
                    Id = Guid.NewGuid(),
                    Nome = "Brenno Cesar de Almeida Baptista",
                    Nascimento = DateTime.Parse("08/02/1995"),
                    Telefone = "21982880402",
                    Email = "brenno_baptista@hotmail.com",
                    Cnh = CNH.NewCNH("06711019630", DateTime.Parse("02/22/2019"), DateTime.Parse("02/22/2024")),
                    Identidade = Identidade.NewIdentidade("271032765", "Detran"),
                    Cpf = CPF.NewCPF("14424377741")
                },
                Veiculo = new Veiculo
                {
                    Id = Guid.NewGuid(),
                    VeiculoDisponivel = true,
                    Marca = "Honda",
                    Modelo = "Civic",
                    Ano = "2019",
                    Cor = "Preto",
                    Chassi = Chassi.NewChassi("01234567891234567"),
                    Placa = Placa.NewPlaca("RIO2A19")
                }
            };

            //Execu��o
            var result = locacaoService.RealizarLocacao(locacao);

            //Valida��o           
            Assert.IsFalse(result);
        }
    }
}