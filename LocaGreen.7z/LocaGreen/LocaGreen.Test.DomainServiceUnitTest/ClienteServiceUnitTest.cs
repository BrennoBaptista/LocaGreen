﻿using LocaGreen.Domain.Entities;
using LocaGreen.Domain.Interfaces.Repositories;
using LocaGreen.Domain.Services;
using LocaGreen.Domain.ValueObjects;
using LocaGreen.Infra.DataAccess.Repositories;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Test.DomainServiceUnitTest
{
    /// <summary>
    /// Teste do CRUD da classe Cliente
    /// </summary>

    public class ClienteServiceUnitTest
    {

        [SetUp]
        public void Setup()
        {
            AdicionarClienteComSucesso();
            LerClienteComSucesso();
            AtualizarClienteComSucesso();
            DeletarClienteComSucesso();
        }

        [Test]
        public void AdicionarClienteComSucesso()
        {
            // Preparação
            IClienteRepository clienteRepository = new ClienteMemDbRepository();
            var clienteService = new ClienteService(clienteRepository);
            var cliente = new Cliente
            {
                Id = Guid.NewGuid(),
                Nome = "Brenno Baptista",
                Nascimento = DateTime.Parse("02/08/1995"),
                Telefone = "21982880402",
                Email = "brenno_baptista@hotmail.com",
                Cpf = CPF.NewCPF("14424377741"),  
                Identidade = Identidade.NewIdentidade("271032765", "detran"),
                Cnh = CNH.NewCNH("1234567", DateTime.Now, DateTime.Now.AddDays(30))
            };

            //Execução
            var result = clienteService.AdicionarCliente(cliente);

            //Validação           
            Assert.IsTrue(result);
        }
        
        [Test]
        public void LerClienteComSucesso()
        {
            // Preparação
            IClienteRepository clienteRepository = new ClienteMemDbRepository();
            var clienteService = new ClienteService(clienteRepository);

            //Execução
            var result = clienteService.ObterClientePorCpf("14424377741");

            //Validação           
            if (result.Identidade.NumeroIdentidade.Equals("271032765"))
                Assert.Pass();
        }

        [Test]
        public void AtualizarClienteComSucesso()
        {
            // Preparação
            IClienteRepository clienteRepository = new ClienteMemDbRepository();
            var clienteService = new ClienteService(clienteRepository);
            var cliente = new Cliente
            {
                Id = Guid.NewGuid(),
                Nome = "Brenno Cesar de Almeida Baptista",
                Nascimento = DateTime.Parse("02/08/1995"),
                Telefone = "21982880402",
                Email = "brenno_baptista@hotmail.com",
                Cpf = CPF.NewCPF("14424377741"),
                Identidade = Identidade.NewIdentidade("271032765", "detran"),
                Cnh = CNH.NewCNH("1234567", DateTime.Now, DateTime.Now.AddDays(30))
            };

            //Execução
            var result = clienteService.AtualizarCliente(cliente);

            //Validação           
            Assert.IsTrue(result);
        }

        [Test]
        public void DeletarClienteComSucesso()
        {
            // Preparação
            IClienteRepository clienteRepository = new ClienteMemDbRepository();
            var clienteService = new ClienteService(clienteRepository);

            //Execução
            var cliente = clienteService.ObterClientePorCpf("14424377741");
            var result = clienteService.DeletarCliente(cliente.Id);

            //Validação           
            Assert.IsTrue(result);
        }
    }
}
