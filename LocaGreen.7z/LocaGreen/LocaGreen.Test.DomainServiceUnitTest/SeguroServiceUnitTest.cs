﻿using LocaGreen.Domain.Entities;
using LocaGreen.Domain.Interfaces.Repositories;
using LocaGreen.Domain.Services;
using LocaGreen.Domain.ValueObjects;
using LocaGreen.Infra.DataAccess.Repositories;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Test.DomainServiceUnitTest
{
    class SeguroServiceUnitTest
    {
        [SetUp]
        public void Setup()
        {
            AdicionarSeguroComSucesso();
        }

        [Test]
        public void AdicionarSeguroComSucesso()
        {
            // Preparação
            ISeguroRepository seguroRepository = new SeguroMemDbRepository();
            var seguroService = new SeguroService(seguroRepository);

            var seguro = new Seguro
            {
                Id = Guid.NewGuid(),
                Apolice = Apolice.NewApolice("12345678910"),
                DataInicioContrato = DateTime.Now,
                DataFimContrato = DateTime.Now.AddDays(30),
                VeiculoSegurado = new Veiculo
                {
                    Id = Guid.NewGuid(),
                    VeiculoDisponivel = true,
                    Marca = "Honda",
                    Modelo = "Civic",
                    Ano = "2019",
                    Cor = "Preto",
                    Chassi = Chassi.NewChassi("01234567891234567"),
                    Placa = Placa.NewPlaca("RIO2A19")
                }
            };

            //Execução
            var result = seguroService.AdicionarSeguro(seguro);

            //Validação           
            Assert.IsTrue(result);
        }
    }
}