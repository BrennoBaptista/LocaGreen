﻿using LocaGreen.Domain.Entities;
using LocaGreen.Domain.Interfaces.Repositories;
using LocaGreen.Domain.Services;
using LocaGreen.Domain.ValueObjects;
using LocaGreen.Infra.DataAccess.Repositories;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Test.DomainServiceUnitTest
{
    public class VeiculoServiceUnitTest
    {

        [SetUp]
        public void Setup()
        {
            AdicionarVeiculoComSucesso();
        }

        [Test]
        public void AdicionarVeiculoComSucesso()
        {
            // Preparação
            IVeiculoRepository veiculoRepository = new VeiculoMemDbRepository();
            var veiculoService = new VeiculoService(veiculoRepository);
            var veiculo = new Veiculo
            {
                Id = Guid.NewGuid(),
                VeiculoDisponivel = true,
                Marca = "Honda",
                Modelo = "Civic",
                Ano = "2019",
                Cor = "Preto",
                Chassi = Chassi.NewChassi("01234567891234567"),
                Placa = Placa.NewPlaca("RIO2A19")
            };

            //Execução
            var result = veiculoService.AdicionarVeiculo(veiculo);

            //Validação           
            Assert.IsTrue(result);
        }
    }
}