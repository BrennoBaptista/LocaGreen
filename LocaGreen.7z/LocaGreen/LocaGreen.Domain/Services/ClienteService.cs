﻿using LocaGreen.Domain.Entities;
using LocaGreen.Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using LocaGreen.Domain.Interfaces.Services;

namespace LocaGreen.Domain.Services
{
    /// <summary>
    /// Implementa os métodos que foram definidos na interface de Serviço do Cliente
    /// </summary>
    public class ClienteService : IClienteService
    {
        protected IClienteRepository _clienteRepository;

        public ClienteService(IClienteRepository clienteRepository)
        {
            _clienteRepository = clienteRepository;
        }

        public bool AdicionarCliente(Cliente cliente)
        {
            return _clienteRepository.Create(cliente);
        }

        public Cliente ObterCliente(Guid id)
        {
            return _clienteRepository.Read(id);
        }

        public Cliente ObterClientePorCpf(string cpf)
        {
            return _clienteRepository.ReadAll()
                .Single(c => c.Cpf == cpf);
        }

        public Cliente ObterClientePorIdentidade(string identidade)
        {
            return _clienteRepository.ReadAll()
                .Single(c => c.Identidade == identidade);
        }

        public Cliente ObterClientePorCnh(string cnh)
        {
            return _clienteRepository.ReadAll()
                .Single(c => c.Cnh == cnh);
        }

        public bool AtualizarCliente(Cliente cliente)
        {
            return _clienteRepository.Update(cliente);
        }

        public bool DeletarCliente(Guid id)
        {
            return _clienteRepository.Delete(id);
        }
    }
}