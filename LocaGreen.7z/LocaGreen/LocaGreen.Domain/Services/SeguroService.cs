﻿using LocaGreen.Domain.Entities;
using LocaGreen.Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using LocaGreen.Domain.Interfaces.Services;

namespace LocaGreen.Domain.Services
{
    /// <summary>
    /// Implementa os métodos que foram definidos na interface de Serviço do Seguro
    /// </summary>
    public class SeguroService : ISeguroService
    {
        protected ISeguroRepository _seguroRepository;

        public SeguroService(ISeguroRepository seguroRepository)
        {
            _seguroRepository = seguroRepository;
        }

        public bool AdicionarSeguro(Seguro seguro)
        {
            return _seguroRepository.Create(seguro);
        }

        public Seguro ObterSeguro(Guid id)
        {
            return _seguroRepository.Read(id);
        }

        public Seguro ObterSeguroPorApolice(string apolice)
        {
            return _seguroRepository.ReadAll()
                .Single(c => c.Apolice == apolice);
        }

        public Seguro ObterSeguroPorPlacaVeiculo(string placaVeiculo)
        {
            return _seguroRepository.ReadAll()
                .Single(c => c.VeiculoSegurado.Placa == placaVeiculo);
        }
    }
}