﻿using LocaGreen.Domain.Entities;
using LocaGreen.Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using LocaGreen.Domain.Interfaces.Services;

namespace LocaGreen.Domain.Services
{
    /// <summary>
    /// Implementa os métodos que foram definidos na interface de Serviço da Locação
    /// </summary>
    public class LocacaoService : ILocacaoService
    {
        protected ILocacaoRepository _locacaoRepository;

        public LocacaoService(ILocacaoRepository locacaoRepository)
        {
            _locacaoRepository = locacaoRepository;
        }

        public bool RealizarLocacao(Locacao locacao)
        {
            if (VerificarLocacao(locacao))
                return _locacaoRepository.Create(locacao);
            else
                return false;
        }

        public bool RealizarDevolucao(Guid locacaoId)
        {
            var locacao = _locacaoRepository.Read(locacaoId);
            return _locacaoRepository.Update(locacao);
        }

        public bool VerificarLocacao(Locacao locacao)
        {
            if (locacao.DataLocacao > locacao.DataDevolucao)
                return false;
            else if (locacao.Veiculo.VeiculoDisponivel == false)
                return false;
            else return true;
        }
    }
}