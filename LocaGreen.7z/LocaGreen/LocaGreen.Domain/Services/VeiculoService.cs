﻿using LocaGreen.Domain.Entities;
using LocaGreen.Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using LocaGreen.Domain.Interfaces.Services;

namespace LocaGreen.Domain.Services
{
    /// <summary>
    /// Implementa os métodos que foram definidos na interface de Serviço do Veículo
    /// </summary>
    public class VeiculoService : IVeiculoService
    {
        protected IVeiculoRepository _veiculoRepository;

        public VeiculoService(IVeiculoRepository veiculoRepository)
        {
            _veiculoRepository = veiculoRepository;
        }

        public bool AdicionarVeiculo(Veiculo veiculo)
        {
            return _veiculoRepository.Create(veiculo);
        }

        public Veiculo ObterVeiculo(Guid id)
        {
            return _veiculoRepository.Read(id);
        }

        public Veiculo ObterVeiculoPorPlaca(string placa)
        {
            return _veiculoRepository.ReadAll()
                .Single(c => c.Placa == placa);
        }

        public Veiculo ObterVeiculoPorChassi(string chassi)
        {
            return _veiculoRepository.ReadAll()
                .Single(c => c.Chassi == chassi);
        }
    }
}