﻿using LocaGreen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.Interfaces.Repositories
{
    /// <summary>
    /// Define métodos e repositórios que serão utilizados na manipulação da classe Locação
    /// </summary>
    public interface ILocacaoRepository : IRepository<Locacao, Guid>
    {

    }
}
