﻿using LocaGreen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.Interfaces.Repositories
{
    /// <summary>
    /// Define métodos e repositórios que serão utilizados na manipulação da classe Veiculo
    /// </summary>
    public interface IVeiculoRepository : IRepository<Veiculo, Guid>
    {

    }
}
