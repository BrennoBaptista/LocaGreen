﻿using LocaGreen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.Interfaces.Repositories
{
    /// <summary>
    /// Define métodos e repositórios que serão utilizados na manipulação da classe Cliente
    /// </summary>
    public interface IClienteRepository : IRepository<Cliente, Guid>
    {

    }
}
