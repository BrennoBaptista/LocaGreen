﻿using LocaGreen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.Interfaces.Repositories
{
    /// <summary>
    /// Define métodos base que serão utilizados na manipulação das classes
    /// </summary>
    public interface IRepository<T,EntidadeId> where T:EntidadeBase<EntidadeId>
    {
        bool Create(T entity);
        T Read(EntidadeId id);
        IEnumerable<T> ReadAll();
        bool Update(T entity);
        bool Delete(EntidadeId id);
    }
}
