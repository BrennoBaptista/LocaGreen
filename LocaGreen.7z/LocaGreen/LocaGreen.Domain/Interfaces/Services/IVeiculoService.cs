﻿using LocaGreen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.Interfaces.Services
{
    /// <summary>
    /// Define os métodos que deverão ser implementados na classe de Serviço do Veículo
    /// </summary>
    interface IVeiculoService
    {
        bool AdicionarVeiculo(Veiculo veiculo);
        Veiculo ObterVeiculo(Guid id);
        Veiculo ObterVeiculoPorPlaca(string placa);
        Veiculo ObterVeiculoPorChassi(string chassi);
    }
}
