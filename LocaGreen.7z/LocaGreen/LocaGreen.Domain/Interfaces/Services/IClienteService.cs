﻿using LocaGreen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.Interfaces.Services
{
    /// <summary>
    /// Define os métodos que deverão ser implementados na classe de Serviço do Cliente
    /// </summary>
    public interface IClienteService
    {
        bool AdicionarCliente(Cliente cliente);
        Cliente ObterCliente(Guid id);
        Cliente ObterClientePorCpf(string cpf);
        Cliente ObterClientePorIdentidade(string identidade);
        Cliente ObterClientePorCnh(string cnh);
        bool AtualizarCliente(Cliente cliente);
        bool DeletarCliente(Guid id);
    }
}
