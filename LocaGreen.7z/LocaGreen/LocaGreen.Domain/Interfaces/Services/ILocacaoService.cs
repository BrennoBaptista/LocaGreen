﻿using LocaGreen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.Interfaces.Services
{
    /// <summary>
    /// Define os métodos que deverão ser implementados na classe de Serviço da Locação
    /// </summary>
    interface ILocacaoService
    {
        bool RealizarLocacao(Locacao locacao);
        bool RealizarDevolucao(Guid locacaoId);
        bool VerificarLocacao(Locacao locacao);
    }
}
