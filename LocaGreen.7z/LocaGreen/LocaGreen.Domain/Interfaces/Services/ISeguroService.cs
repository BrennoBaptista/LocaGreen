﻿using LocaGreen.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.Interfaces.Services
{
    /// <summary>
    /// Define os métodos que deverão ser implementados na classe de Serviço do Seguro
    /// </summary>
    interface ISeguroService
    {
        bool AdicionarSeguro(Seguro seguro);
        Seguro ObterSeguro(Guid id);
        Seguro ObterSeguroPorApolice(string apolice);
        Seguro ObterSeguroPorPlacaVeiculo(string placaVeiculo);
    }
}
