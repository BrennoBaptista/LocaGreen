﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.ValueObjects
{
    /// <summary>
    /// Objeto de valor da classe Veículo
    /// </summary>
    public struct Placa
    {
        public string CodigoPlaca { get; set; }

        public Placa (string codigoPlaca)
        {
            if(codigoPlaca.Length > 7)
                throw new ArgumentOutOfRangeException("Este placa não é válida");

            CodigoPlaca = codigoPlaca;
        }

        public static Placa NewPlaca(string codigoPlaca)
        {
            return new Placa(codigoPlaca);
        }

        public static implicit operator string(Placa placa)
        {
            return placa.CodigoPlaca;
        }
    }
}