﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.ValueObjects
{
    /// <summary>
    /// Objeto de valor da classe Cliente
    /// </summary>
    public struct Identidade
    {
        public string NumeroIdentidade { get; set; }
        public string OrgaoExpedidor { get; set; }

        public Identidade (string numeroidentidade, string orgaoexpedidor)
        {
            if (numeroidentidade.Length > 9)
                throw new ArgumentOutOfRangeException("Este numero de identidade não é válido");

            NumeroIdentidade = numeroidentidade;
            OrgaoExpedidor = orgaoexpedidor;
        }

        public static Identidade NewIdentidade(string numeroIdentidade, string orgaoExpedidor)
        {
            return new Identidade(numeroIdentidade, orgaoExpedidor);
        }

        public static implicit operator string(Identidade identidade)
        {
            return identidade.NumeroIdentidade;
        }
    }
}