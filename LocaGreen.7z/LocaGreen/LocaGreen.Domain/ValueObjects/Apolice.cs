﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.ValueObjects
{
    /// <summary>
    /// Objeto de valor da classe Seguro
    /// </summary>
    public struct Apolice
    {
        public string NumeroApolice { get; set; }

        public Apolice(string numeroApolice)
        {
            if (numeroApolice.Length > 15)
                throw new ArgumentOutOfRangeException("Este número de protocolo não é válido");

            NumeroApolice = numeroApolice;
        }

        public static Apolice NewApolice(string numeroApolice)
        {
            return new Apolice(numeroApolice);
        }

        public static implicit operator string(Apolice apolice)
        {
            return apolice.NumeroApolice;
        }
    }
}