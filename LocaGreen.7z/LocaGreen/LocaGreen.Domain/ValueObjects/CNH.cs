﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.ValueObjects
{
    /// <summary>
    /// Objeto de valor da classe Cliente
    /// </summary>
    public struct CNH
    { 
        public string NumeroRegistro { get; set; }
        public DateTime DataEmissao { get; set; }
        public DateTime DataVencimento { get; set; }

        public CNH(string numeroRegistro, DateTime dataEmissao, DateTime dataVencimento)
        {
            if (numeroRegistro.Length > 11 || numeroRegistro.Length == 0)
                throw new ArgumentOutOfRangeException("Este numero de registro da CNH não é válido");
            else if(DateTime.Now > dataVencimento)
                throw new ArgumentOutOfRangeException("Esta CNH está vencida");

            NumeroRegistro = numeroRegistro;
            DataEmissao = dataEmissao;
            DataVencimento = dataVencimento;
        }

        public static CNH NewCNH(string numeroRegistro, DateTime dataEmissao, DateTime dataVencimento)
        {
            return new CNH(numeroRegistro, dataEmissao, dataVencimento);
        }

        public static implicit operator string(CNH cnh)
        {
            return cnh.NumeroRegistro;
        }
    }
}