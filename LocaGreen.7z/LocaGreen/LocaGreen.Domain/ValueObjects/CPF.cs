﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.ValueObjects
{
    /// <summary>
    /// Objeto de valor da classe Cliente
    /// </summary>
    public struct CPF
    {
        public string NumeroCpf { get; set; }

        public CPF (string numeroCpf)
        {
            if (numeroCpf.Length > 11)
                throw new ArgumentOutOfRangeException("Este numero de CPF não é válido");

            NumeroCpf = numeroCpf;
        }

        public static CPF NewCPF(string numeroCpf)
        {
            return new CPF(numeroCpf);
        }

        public static implicit operator string(CPF cpf)
        {
            return cpf.NumeroCpf;
        }
    }
}