﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.ValueObjects
{
    /// <summary>
    /// Objeto de valor da classe Veículo
    /// </summary>
    public struct Chassi
    {
        public string NumeroChassi { get; set; }

        public Chassi(string numeroChassi)
        {
            if(numeroChassi.Length > 17)
                throw new ArgumentOutOfRangeException("Este numero de Chassi não é válido");

            NumeroChassi = numeroChassi;
        }

        public static Chassi NewChassi(string numeroChassi)
        {
            return new Chassi(numeroChassi);
        }

        public static implicit operator string(Chassi chassi)
        {
            return chassi.NumeroChassi;
        }
    }
}