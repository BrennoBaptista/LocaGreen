﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.Entities
{
    /// <summary>
    /// O domínio deste projeto é sobre a locadora de veículos LocaGreen. 
    /// A locadora possui diversos clientes e para garantir sua segurança, todos os veículos possuem uma apólice de seguro.
    /// </summary>

    public class Locacao : EntidadeBase<Guid>
    {
        /// <summary>
        /// Representa o relacionamento de um cliente com o veículo alugado.
        /// </summary>
        public DateTime DataLocacao { get; set; }
        public DateTime DataDevolucao { get; set; }
        public Cliente Cliente { get; set; }
        public Veiculo Veiculo { get; set; }
        //Variável que identifica se a locação está ativa ou não.
        public bool LocacaoAtiva { get; set; }
    }
}
