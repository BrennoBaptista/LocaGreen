﻿using LocaGreen.Domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.Entities
{
    public class Cliente : EntidadeBase<Guid>
    {
        /// <summary>
        /// Representa a pessoa que vai alugar um veículo.
        /// </summary>
        public string Nome { get; set; }
        public DateTime Nascimento { get; set; }
        public string Telefone { get; set; }
        public string Email { get; set; }
        public CNH Cnh { get; set; }
        public Identidade Identidade { get; set; }
        public CPF Cpf { get; set; }
    }
}
