﻿using LocaGreen.Domain.ValueObjects;
using System;

namespace LocaGreen.Domain.Entities
{
    public class Veiculo : EntidadeBase<Guid>
    {
        /// <summary>
        /// Representa o relacionamento do veículo a ser alugado por um cliente.
        /// </summary>
        
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string Ano { get; set; }
        public string Cor { get; set; }
        public Chassi Chassi { get; set; }
        public Placa Placa { get; set; }
        //Variável que identifica se o veículo está disponível ou não.
        public bool VeiculoDisponivel { get; set; }
    }
}
