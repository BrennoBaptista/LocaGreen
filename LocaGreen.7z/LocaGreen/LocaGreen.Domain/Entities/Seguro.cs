﻿using LocaGreen.Domain.ValueObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.Entities
{
    public class Seguro : EntidadeBase<Guid>
    {
        /// <summary>
        /// Representa a entidade Seguro que é o relacionamento de um veículo com o seu seguro.
        /// </summary>
        public Apolice Apolice  { get; set; }
        public Veiculo VeiculoSegurado { get; set; }
        public DateTime DataInicioContrato { get; set; }
        public DateTime DataFimContrato { get; set; }
    }
}

