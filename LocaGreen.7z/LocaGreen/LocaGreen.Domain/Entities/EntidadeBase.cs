﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LocaGreen.Domain.Entities
{
    /// <summary>
    /// Representa o atributo identificador de todas as classes
    /// </summary>
    public abstract class EntidadeBase<EntidadeID>
    {
        public EntidadeID Id { get; set; }
    }
}
